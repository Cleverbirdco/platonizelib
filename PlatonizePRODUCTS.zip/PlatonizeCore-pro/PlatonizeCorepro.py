import numpy as np
import json
import os
import copy
import logging
import time
import sqlite3
from sklearn.model_selection import train_test_split
from typing import List
from joblib import Parallel, delayed
import asyncio
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.feature_selection import SelectKBest, f_classif
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.impute import KNNImputer
from sklearn.linear_model import LinearRegression
import seaborn as sns
import matplotlib.pyplot as plt
import requests
from geopy.geocoders import Nominatim
from textblob import TextBlob
import csv
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import pandas as pd

#data manupilation
# lists
def filter_list(data, condition):
    """
    Filters elements of a list based on a condition.

    Args:
        data (list): The list of elements to filter.
        condition (function): A function that returns True for elements to include.

    Returns:
        list: A new list containing elements that satisfy the condition.
    """
  
    return [item for item in data if condition(item)]
    """
    # Example usage:
    numbers = [1, 2, 3, 4, 5, 6, 10, 12,30 , 45, 47 , 39 ,29 , 2820, 13,  2987362, 83737636, 100000, 38383, 6969696, 17267262]
    even_numbers = filter_list(numbers, lambda x: x % 2 == 0)
    print(even_numbers)  # Output: [2, 4, 6]
 
    """
  




def sort_list(data, key=None, reverse=False):
    """
    Sorts a list by a key or default order.

    Args:
        data (list): The list of elements to sort.
        key (function, optional): A function to specify the sort key. Defaults to None.
        reverse (bool, optional): If True, sorts in descending order. Defaults to False.

    Returns:
        list: A new sorted list.
    """
    return sorted(data, key=key, reverse=reverse)
    """
    # Example usage:
    numbers = [5, 2, 9, 1, 5, 6]
    sorted_numbers = sort_list(numbers)
    print(sorted_numbers)  # Output: [1, 2, 5, 5, 6, 9]

    # Sorting with a custom key
    names = ["Alice", "Bob", "Charlie", "Dave"]
    sorted_names = sort_list(names, key=len)
    print(sorted_names)  # Output: ['Bob', 'Dave', 'Alice', 'Charlie']

    # Sorting in reverse order
    reverse_sorted_numbers = sort_list(numbers, reverse=True)
    print(reverse_sorted_numbers)  # Output: [9, 6, 5, 5, 2, 1]
    """



def transform_list(data, function):
    """
    Applies a transformation function to each element of a list.

    Args:
        data (list): The list of elements to transform.
        function (function): A function that defines how to transform each element.

    Returns:
        list: A new list with the transformed elements.
    """
    return [function(item) for item in data]

    """  
    # Example usage:
numbers = [1, 2, 3, 4, 5]
squared_numbers = transform_list(numbers, lambda x: x ** 2)
print(squared_numbers)  # Output: [1, 4, 9, 16, 25]

# Transforming strings
names = ["alice", "bob", "charlie"]
capitalized_names = transform_list(names, str.capitalize)
print(capitalized_names)  # Output: ['Alice', 'Bob', 'Charlie']
    """



def merge_lists(list1, list2, merge_func):
    """
    Merges two lists using a custom merge function.

    Args:
        list1 (list): The first list to merge.
        list2 (list): The second list to merge.
        merge_func (function): A function defining how to merge elements from both lists.

    Returns:
        list: A new list with merged elements.
    """
    return [merge_func(item1, item2) for item1, item2 in zip(list1, list2)]
    """
# Example usage:
list1 = [1, 2, 3]
list2 = [4, 5, 6]
summed_list = merge_lists(list1, list2, lambda x, y: x + y)
print(summed_list)  # Output: [5, 7, 9]

# Merging strings
names1 = ["Alice", "Bob", "Charlie"]
names2 = ["Smith", "Brown", "Davis"]
merged_names = merge_lists(names1, names2, lambda x, y: f"{x} {y}")
print(merged_names)  # Output: ['Alice Smith', 'Bob Brown', 'Charlie Davis']
    """




def aggregate_list(data, agg_func):
    """
    Aggregates list values using a provided aggregation function.

    Args:
        data (list): The list of values to aggregate.
        agg_func (function): A function that defines how to aggregate the list values.

    Returns:
        Any: The aggregated result, as determined by the aggregation function.
    """
    return agg_func(data)
    """
    # Example usage:
numbers = [1, 2, 3, 4, 5]

# Aggregating with sum
total = aggregate_list(numbers, sum)
print(total)  # Output: 15

# Aggregating with average
average = aggregate_list(numbers, lambda x: sum(x) / len(x))
print(average)  # Output: 3.0

# Aggregating with max
maximum = aggregate_list(numbers, max)
print(maximum)  # Output: 5
    """

# sec numpy



def filter_array(array, condition):
    """
    Filters elements of a NumPy array based on a condition.

    Args:
        array (np.ndarray): The NumPy array to filter.
        condition (function): A function that returns True for elements to include.

    Returns:
        np.ndarray: A new array with elements that satisfy the condition.
    """
    """
    """
    return array[condition(array)]
    """
    
# Example usage:
arr = np.array([1, 2, 3, 4, 5, 6])

# Filtering even numbers
even_numbers = filter_array(arr, lambda x: x % 2 == 0)
print(even_numbers)  # Output: [2 4 6]

# Filtering elements greater than 3
greater_than_three = filter_array(arr, lambda x: x > 3)
print(greater_than_three)  # Output: [4 5 6]

    """



def sort_array(array, axis=-1):
    """
    Sorts a NumPy array along a specified axis.

    Args:
        array (np.ndarray): The NumPy array to sort.
        axis (int, optional): The axis along which to sort. Defaults to -1 (last axis).

    Returns:
        np.ndarray: A sorted NumPy array.
    """
    return np.sort(array, axis=axis)
    """
    # Example usage:
arr = np.array([[3, 1, 2], [6, 5, 4]])
sorted_arr = sort_array(arr, axis=1)
print(sorted_arr)  # Output: [[1 2 3]
                   #          [4 5 6]]
    """


def transform_array(array, function):

    """
    Applies a function to each element of a NumPy array.

    Args:
        array (np.ndarray): The NumPy array to transform.
        function (function): A function to apply to each element.

    Returns:
        np.ndarray: A transformed NumPy array.
    """
    return np.vectorize(function)(array)
    """
    # Example usage:
# Create a 1D array of numbers.
arr = np.array([1, 2, 3, 4, 5])
# Apply a transformation: square each element.
squared_arr = transform_array(arr, lambda x: x ** 2)
print(squared_arr)  # Output: [ 1  4  9 16 25]

# Apply another transformation: convert to strings.
string_arr = transform_array(arr, str)
print(string_arr)  # Output: ['1' '2' '3' '4' '5']


    """


def aggregate_array(array, agg_func, axis=None):
    """
    Aggregates values of a NumPy array along a specified axis.

    Args:
        array (np.ndarray): The NumPy array to aggregate.
        agg_func (function): A function to aggregate values (e.g., np.sum, np.mean).
        axis (int, optional): The axis along which to aggregate. Defaults to None (aggregate all values).

    Returns:
        Any: The aggregated result.
    """
    return agg_func(array, axis=axis)
    """
    # Example usage:
# Create a 2D array of numbers.
arr = np.array([[1, 2, 3], [4, 5, 6]])

# Compute the sum of each row (axis=1).
sum_rows = aggregate_array(arr, np.sum, axis=1)
print(sum_rows)  # Output: [ 6 15]

# Compute the mean of each column (axis=0).
mean_columns = aggregate_array(arr, np.mean, axis=0)
print(mean_columns)  # Output: [2.5 3.5 4.5]

# Compute the total sum of all elements in the array.
total_sum = aggregate_array(arr, np.sum)
print(total_sum)  # Output: 21
   

    """
    



def filter_dict(data, condition):
    """
    Filters dictionary entries based on a condition.

    Args:
        data (dict): The dictionary to filter.
        condition (function): A function that takes a key-value pair and returns True for entries to keep.

    Returns:
        dict: A new dictionary with filtered entries.
    # Example usage:
# Dictionary to filter
data = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Keep entries where the value is even
filtered_dict = filter_dict(data, lambda k, v: v % 2 == 0)
print(filtered_dict)  # Output: {'b': 2, 'd': 4}

# Keep entries where the key starts with 'c'
filtered_dict_by_key = filter_dict(data, lambda k, v: k.startswith('c'))
print(filtered_dict_by_key)  # Output: {'c': 3}



    """
    
    return {k: v for k, v in data.items() if condition(k, v)}



def map_dict(data, transform_func):
    """
    Transforms keys or values in a dictionary using a function.

    Args:
        data (dict): The dictionary to transform.
        transform_func (function): A function that takes a key-value pair and returns a new key-value pair.

    Returns:
        dict: A new dictionary with transformed entries.
    # Example usage:
# Dictionary to transform
data = {'a': 1, 'b': 2, 'c': 3}

# Multiply values by 10
transformed_dict = map_dict(data, lambda k, v: (k, v * 10))
print(transformed_dict)  # Output: {'a': 10, 'b': 20, 'c': 30}

# Change keys to uppercase
uppercase_keys_dict = map_dict(data, lambda k, v: (k.upper(), v))
print(uppercase_keys_dict)  # Output: {'A': 1, 'B': 2, 'C': 3}
    """
    return {new_k: new_v for k, v in data.items() for new_k, new_v in [transform_func(k, v)]}





def merge_dicts(dict1, dict2, conflict_resolver):
    """
    Merges two dictionaries, resolving conflicts with a provided function.

    Args:
        dict1 (dict): The first dictionary.
        dict2 (dict): The second dictionary.
        conflict_resolver (function): A function to resolve conflicts. It takes two values and returns the resolved value.

    Returns:

        dict: A new merged dictionary.
    
# Example usage:
dict1 = {'a': 1, 'b': 2}
dict2 = {'b': 3, 'c': 4}

# Resolve conflicts by summing values
merged_dict = merge_dicts(dict1, dict2, lambda x, y: x + y)
print(merged_dict)  # Output: {'a': 1, 'b': 5, 'c': 4}


    """
    merged = dict1.copy()
    for k, v in dict2.items():
        if k in merged:
            merged[k] = conflict_resolver(merged[k], v)
        else:
            merged[k] = v
    return merged






def group_by_key(data, key):
    """
    Groups a list of dictionaries by a specific key.

    Args:
        data (list of dict): The list of dictionaries to group.
        key (str): The key to group by.

    Returns:
        dict: A dictionary where each key is a unique value from the specified key, 
              and each value is a list of dictionaries sharing that key value.
    # Example usage:
data = [
    {'name': 'Alice', 'age': 25, 'department': 'HR'},
    {'name': 'Bob', 'age': 30, 'department': 'IT'},
    {'name': 'Charlie', 'age': 22, 'department': 'HR'},
]

# Group by department
grouped_data = group_by_key(data, 'department')
print(grouped_data)
# Output:
# {
#     'HR': [{'name': 'Alice', 'age': 25, 'department': 'HR'},
#            {'name': 'Charlie', 'age': 22, 'department': 'HR'}],
#     'IT': [{'name': 'Bob', 'age': 30, 'department': 'IT'}]
# }


    """
    grouped = {}
    for item in data:
        grouped.setdefault(item[key], []).append(item)
    return grouped





import pandas as pd

def filter_df(df, condition):
    """
    Filters rows in a DataFrame based on a condition.

    Args:
        df (pd.DataFrame): The DataFrame to filter.
        condition (function): A function that takes a row (Series) and returns True for rows to keep.

    Returns:
        pd.DataFrame: A new DataFrame with filtered rows.
    # Example usage:
data = {'Name': ['Alice', 'Bob', 'Charlie'], 'Age': [25, 30, 22]}
df = pd.DataFrame(data)

# Filter rows where Age > 25
filtered_df = filter_df(df, lambda row: row['Age'] > 25)
print(filtered_df)
# Output:
#   Name  Age
# 1  Bob   30



    """
    return df[df.apply(condition, axis=1)]




def sort_df(df, columns, ascending=True):
    """
    Sorts a DataFrame by specified columns.

    Args:
        df (pd.DataFrame): The DataFrame to sort.
        columns (list or str): Column(s) to sort by.
        ascending (bool or list, optional): Sort order(s). Defaults to True.

    Returns:
        pd.DataFrame: A sorted DataFrame.
    # Example usage:
data = {'Name': ['Alice', 'Bob', 'Charlie'], 'Age': [25, 30, 22]}
df = pd.DataFrame(data)

# Sort by Age in ascending order
sorted_df = sort_df(df, 'Age')
print(sorted_df)
# Output:
#       Name  Age
# 2  Charlie   22
# 0    Alice   25
# 1      Bob   30


    """
    return df.sort_values(by=columns, ascending=ascending)






def transform_df(df, column, function):
    """
    Applies a function to a column in a DataFrame.

    Args:
        df (pd.DataFrame): The DataFrame to transform.
        column (str): The column to apply the function to.
        function (function): A function to apply to the column.

    Returns:
        pd.DataFrame: The DataFrame with the transformed column.
    # Example usage:
data = {'Name': ['Alice', 'Bob', 'Charlie'], 'Age': [25, 30, 22]}
df = pd.DataFrame(data)

# Add 5 to each value in the Age column
transformed_df = transform_df(df, 'Age', lambda x: x + 5)
print(transformed_df)
# Output:
#       Name  Age
# 0    Alice   30
# 1      Bob   35
# 2  Charlie   27

    """
    df[column] = df[column].apply(function)
    return df



def merge_dfs(df1, df2, on, how='inner'):
    """
    Merges two DataFrames on specified keys.

    Args:
        df1 (pd.DataFrame): The first DataFrame.
        df2 (pd.DataFrame): The second DataFrame.
        on (str or list): Column(s) to merge on.
        how (str, optional): Type of merge ('inner', 'outer', 'left', 'right'). Defaults to 'inner'.

    Returns:
        pd.DataFrame: The merged DataFrame.
    
# Example usage:
data1 = {'ID': [1, 2], 'Name': ['Alice', 'Bob']}
data2 = {'ID': [1, 3], 'Score': [90, 85]}
df1 = pd.DataFrame(data1)
df2 = pd.DataFrame(data2)

# Merge on the 'ID' column
merged_df = merge_dfs(df1, df2, on='ID')
print(merged_df)
# Output:
#    ID   Name  Score
# 0   1  Alice     90


    """
    return pd.merge(df1, df2, on=on, how=how)





def aggregate_df(df, group_by, agg_func):
    """
    Aggregates a DataFrame by groups using a function.

    Args:
        df (pd.DataFrame): The DataFrame to aggregate.
        group_by (str or list): Column(s) to group by.
        agg_func (dict or callable): Aggregation function(s) to apply.

    Returns:
        pd.DataFrame: The aggregated DataFrame.
    # Example usage:
data = {'Department': ['HR', 'IT', 'HR', 'IT'], 'Salary': [50000, 60000, 55000, 70000]}
df = pd.DataFrame(data)

# Aggregate by department, calculating the mean salary
aggregated_df = aggregate_df(df, 'Department', {'Salary': 'mean'})
print(aggregated_df)
# Output:
#   Department   Salary
# 0         HR  52500.0
# 1         IT  65000.0



    """
    return df.groupby(group_by).agg(agg_func).reset_index()




def filter_data(data, condition):
    """
    Filters data (list, dictionary, or DataFrame) based on a condition.

    Args:
        data (list, dict, or pd.DataFrame): The data structure to filter.
        condition (function): The condition function for filtering.

    Returns:
        The filtered data structure.
    
# Example usage:
# For a list
data_list = [1, 2, 3, 4]
filtered_list = filter_data(data_list, lambda x: x % 2 == 0)
print(filtered_list)  # Output: [2, 4]

# For a dictionary
data_dict = {'a': 1, 'b': 2, 'c': 3}
filtered_dict = filter_data(data_dict, lambda k, v: v > 1)
print(filtered_dict)  # Output: {'b': 2, 'c': 3}

# For a DataFrame
df = pd.DataFrame({'Name': ['Alice', 'Bob', 'Charlie'], 'Age': [25, 30, 22]})
filtered_df = filter_data(df, lambda row: row['Age'] > 25)
print(filtered_df)

    """
    if isinstance(data, list):
        return [item for item in data if condition(item)]
    elif isinstance(data, dict):
        return {k: v for k, v in data.items() if condition(k, v)}
    elif isinstance(data, pd.DataFrame):
        return data[data.apply(condition, axis=1)]
    else:
        raise ValueError("Unsupported data type")






def sort_data(data, key=None, reverse=False):
    """
    Sorts data (list, dictionary, or DataFrame) based on a key or default order.

    Args:
        data (list, dict, or pd.DataFrame): The data structure to sort.
        key (function or str, optional): Sorting key (for lists and dicts).
        reverse (bool, optional): If True, sorts in descending order.

    Returns:
        The sorted data structure.
    # Example usage:
# For a list
sorted_list = sort_data([3, 1, 2], reverse=True)
print(sorted_list)  # Output: [3, 2, 1]

# For a dictionary (sorting by value)
sorted_dict = sort_data({'a': 1, 'b': 3, 'c': 2}, key=lambda item: item[1])
print(sorted_dict)  # Output: {'a': 1, 'c': 2, 'b': 3}

# For a DataFrame
df = pd.DataFrame({'Name': ['Alice', 'Bob', 'Charlie'], 'Age': [25, 30, 22]})
sorted_df = sort_data(df, key='Age', reverse=True)
print(sorted_df)


    """
    if isinstance(data, list):
        return sorted(data, key=key, reverse=reverse)
    elif isinstance(data, dict):
        return {k: v for k, v in sorted(data.items(), key=key, reverse=reverse)}
    elif isinstance(data, pd.DataFrame):
        return data.sort_values(by=key, ascending=not reverse)
    else:
        raise ValueError("Unsupported data type")





def transform_data(data, function):
    """
    Applies transformations to data (list, dictionary, or DataFrame/Series) using a function.

    Args:
        data (list, dict, pd.DataFrame, or pd.Series): The data structure to transform.
        function (function): The function to apply to each element.

    Returns:
        The transformed data structure.
    # Example usage with Series (single column):
df = pd.DataFrame({'Name': ['Alice', 'Bob', 'Charlie'], 'Age': [25, 30, 22]})
transformed_df = transform_data(df['Age'], lambda x: x + 5)
print(transformed_df)  # Output: 0    30, 1    35, 2    27
    """
    if isinstance(data, list):
        return [function(item) for item in data]
    elif isinstance(data, dict):
        return {k: function(v) for k, v in data.items()}
    elif isinstance(data, pd.DataFrame):
        return data.apply(function, axis=1)  # Apply function to each row
    elif isinstance(data, pd.Series):
        return data.apply(function)  # Apply function to each element of the Series
    else:
        raise ValueError("Unsupported data type")


def merge_data(data1, data2, merge_func=None):
    """
    Merges two data structures (list, dictionary, or DataFrame) with type-specific logic.

    Args:
        data1 (list, dict, or pd.DataFrame): The first data structure.
        data2 (list, dict, or pd.DataFrame): The second data structure.
        merge_func (function, optional): Custom merge function for lists or dictionaries.

    Returns:
        The merged data structure.
    # Example usage:
# For two lists
merged_list = merge_data([1, 2], [3, 4])
print(merged_list)  # Output: [1, 2, 3, 4]

# For two dictionaries (merging values by adding them)
merged_dict = merge_data({'a': 1, 'b': 2}, {'b': 3, 'c': 4}, merge_func=lambda x, y: x + y)
print(merged_dict)  # Output: {'a': 1, 'b': 5, 'c': 4}

# For two DataFrames
df1 = pd.DataFrame({'Name': ['Alice', 'Bob'], 'Age': [25, 30]})
df2 = pd.DataFrame({'Name': ['Charlie'], 'Age': [22]})
merged_df = merge_data(df1, df2)
print(merged_df)

    """
    if isinstance(data1, list) and isinstance(data2, list):
        if merge_func:
            return merge_func(data1, data2)
        return data1 + data2
    elif isinstance(data1, dict) and isinstance(data2, dict):
        merged = data1.copy()
        for k, v in data2.items():
            if k in merged:
                merged[k] = merge_func(merged[k], v) if merge_func else v
            else:
                merged[k] = v
        return merged
    elif isinstance(data1, pd.DataFrame) and isinstance(data2, pd.DataFrame):
        return pd.concat([data1, data2], ignore_index=True)
    else:
        raise ValueError("Unsupported data types for merging")








def aggregate_data(data, agg_func):
    """
    Aggregates data (list, dictionary, or DataFrame/Series) using a function.

    Args:
        data (list, dict, pd.DataFrame, or pd.Series): The data structure to aggregate.
        agg_func (function): The aggregation function.

    Returns:
        The aggregated result.
    # Example usage:
# For a list
aggregated_list = aggregate_data([1, 2, 3, 4], sum)
print(aggregated_list)  # Output: 10

# For a dictionary (sum of values)
aggregated_dict = aggregate_data({'a': 1, 'b': 2, 'c': 3}, sum)
print(aggregated_dict)  # Output: 6

# For a DataFrame column (mean of a single column)
df = pd.DataFrame({'Name': ['Alice', 'Bob', 'Charlie'], 'Age': [25, 30, 22]})
aggregated_age = aggregate_data(df['Age'], lambda x: x.mean())
print(aggregated_age)  # Output: 25.666666666666668

    """
    if isinstance(data, list):
        return agg_func(data)
    elif isinstance(data, dict):
        return agg_func(list(data.values()))
    elif isinstance(data, pd.DataFrame):
        return agg_func(data)  # Apply agg_func to the entire DataFrame
    elif isinstance(data, pd.Series):
        return agg_func(data)  # Apply agg_func to the Series
    else:
        raise ValueError("Unsupported data type")















def validate_data(data, schema):
    """
    Validates data against a predefined schema or rules.

    Args:
        data (dict): The data to validate.
        schema (dict): The schema defining validation rules.

    Returns:
        bool: True if the data is valid according to the schema, otherwise False.
    
# Example usage:
data = {"name": "Alice", "age": 25}
schema = {"name": str, "age": int}

try:
    is_valid = validate_data(data, schema)
    print("Data is valid:", is_valid)
except (ValueError, TypeError) as e:
    print(f"Validation failed: {e}")
    """
    for key, value_type in schema.items():
        if key not in data:
            raise ValueError(f"Missing required key: {key}")
        if not isinstance(data[key], value_type):
            raise TypeError(f"Invalid type for key '{key}': Expected {value_type}, got {type(data[key])}")
    return True









def validate_file(filepath, format):
    """
    Ensures the file conforms to a specified format (e.g., JSON, CSV).

    Args:
        filepath (str): Path to the file to validate.
        format (str): The expected format (e.g., 'json', 'csv').

    Returns:
        bool: True if the file is valid according to the format, otherwise False.
    # Example usage:
try:
    is_valid = validate_file('data.json', 'json')
    print("File is valid:", is_valid)
except (FileNotFoundError, ValueError) as e:
    print(f"File validation failed: {e}")
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"File not found: {filepath}")
    
    if format == 'json':
        try:
            with open(filepath, 'r') as f:
                json.load(f)  # Try loading as JSON
            return True
        except json.JSONDecodeError:
            raise ValueError("Invalid JSON format")
    elif format == 'csv':
        # Placeholder for CSV validation (can use pandas or csv module)
        raise NotImplementedError("CSV validation not yet implemented")
    else:
        raise ValueError("Unsupported file format")
        








# Configure logging to show only ERROR messages
logging.basicConfig(level=logging.ERROR)

def handle_errors(operation, fallback):
    """
    Wrapper to handle and log errors gracefully.

    Args:
        operation (callable): The operation to execute.
        fallback (callable): The function to call in case of error.

    Returns:
        The result of the operation if successful, or the fallback value if an error occurs.
    # Example usage:
def risky_operation():
    # Simulate an operation that could raise an error
    raise ValueError("Something went wrong!")

def fallback_operation():
    return "Fallback value"

result = handle_errors(risky_operation, fallback_operation)
print("Result:", result)
    """
    try:
        return operation()
    except Exception as e:
        logging.error(f"Error occurred: {e}")  # Log only errors
        return fallback()










def create_pipeline(steps):
    """
    Creates a pipeline with a series of transformations.

    Args:
        steps (list of functions): A list of functions to apply in sequence.

    Returns:
        list: A pipeline represented as a list of transformation functions.
    # Example usage:
def step1(data):
    return [x + 1 for x in data]

def step2(data):
    return [x * 2 for x in data]

pipeline = create_pipeline([step1, step2])
print(pipeline)  # Output: [<function step1 at ...>, <function step2 at ...>]

    """
    if not all(callable(step) for step in steps):
        raise ValueError("All steps must be callable functions")
    return steps











def run_pipeline(data, pipeline):
    """
    Executes a defined pipeline on the given data.

    Args:
        data (any): The input data to process.
        pipeline (list): The pipeline, which is a list of transformation functions.

    Returns:
        The processed data after applying the pipeline steps.
    # Example usage:
# Step definitions
def step1(data):
    return [x + 1 for x in data]

def step2(data):
    return [x * 2 for x in data]

# Create a pipeline with step1 and step2
pipeline = create_pipeline([step1, step2])

# Input data
data = [1, 2, 3]

# Run the pipeline on the data
result = run_pipeline(data, pipeline)

# Output the result
print(result)  # Expected Output: [4, 6, 8]
    """
    for step in pipeline:
        data = step(data)  # Apply each transformation step in sequence
    return data






# Process batch
def process_batch(batch, pipeline):
    """
    Processes data in batches using a pipeline.

    Args:
        batch (list): A list of data items to process.
        pipeline (list): The pipeline, which is a list of transformation functions.

    Returns:
        list: The processed batch after applying the pipeline steps.
    # Example usage:
# Step definitions
def step1(data):
    return [x + 1 for x in data]

def step2(data):
    return [x * 2 for x in data]

# Create a pipeline with step1 and step2
pipeline = create_pipeline([step1, step2])

# Example batch of data
batch = [1, 2, 3]

# Process the batch using the pipeline
processed_batch = process_batch(batch, pipeline)

# Output the result
print(processed_batch)  # Expected Output: [4, 6, 8]
    """
    return run_pipeline(batch, pipeline)



# Stream data
def stream_data(data_source, pipeline):
    """
    Applies a pipeline to streaming data.

    Args:
        data_source (iterable): A streaming data source (like a generator or list).
        pipeline (list): The pipeline, which is a list of transformation functions.

    Returns:
        list: The processed data after applying the pipeline steps.
    # Example usage:
# Step definitions
def step1(data):
    return [x + 1 for x in data]

def step2(data):
    return [x * 2 for x in data]

# Create a pipeline with step1 and step2
pipeline = create_pipeline([step1, step2])

# Example streaming data (could be a generator or any iterable)
data_source = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]

# Stream the data through the pipeline
processed_data = stream_data(data_source, pipeline)

# Output the result
print(processed_data)  # Expected Output: [[4, 6, 8], [10, 12, 14], [14, 16, 18]]
    """
    result = []
    for data in data_source:
        result.append(run_pipeline(data, pipeline))
    return result




















def export_to_csv(data, filepath):
    """
    Exports data to a CSV file.

    Args:
        data (list of dict): List of dictionaries representing rows.
        filepath (str): The path where the CSV file will be saved.
    """
    if not data:
        raise ValueError("Data cannot be empty")
    
    # Assuming data is a list of dictionaries
    keys = data[0].keys()
    
    with open(filepath, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.DictWriter(file, fieldnames=keys)
        writer.writeheader()
        writer.writerows(data)
    print(f"Data has been exported to {filepath}")




def export_to_json(data, filepath):
    """
    Saves data as a JSON file.

    Args:
        data (any): The data to be saved (can be any serializable structure).
        filepath (str): The path where the JSON file will be saved.
    """
    with open(filepath, 'w', encoding='utf-8') as file:
        json.dump(data, file, ensure_ascii=False, indent=4)
    print(f"Data has been exported to {filepath}")







def export_to_excel(data, filepath, sheet_name='Sheet1'):
    """
    Saves data to an Excel sheet.

    Args:
        data (list of dict or DataFrame): The data to be exported.
        filepath (str): The path where the Excel file will be saved.
        sheet_name (str): The name of the sheet in the Excel file.
    """
    # If the data is a list of dictionaries, convert to DataFrame
    if isinstance(data, list):
        data = pd.DataFrame(data)
    
    data.to_excel(filepath, sheet_name=sheet_name, index=False)
    print(f"Data has been exported to {filepath}")







  # Example with SQLite; adapt for other databases like MySQL or PostgreSQL

def export_to_database(data, connection, table_name):
    """
    Exports data to a database table.

    Args:
        data (list of dict): List of dictionaries representing rows.
        connection (sqlite3.Connection or any DB connection object): Database connection.
        table_name (str): The name of the table where data will be inserted.
    """
    if not data:
        raise ValueError("Data cannot be empty")
    
    # Create a cursor object
    cursor = connection.cursor()
    
    # Create an insert query based on the keys of the dictionary
    columns = ', '.join(data[0].keys())
    placeholders = ', '.join(['?'] * len(data[0]))
    
    query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
    
    # Insert data into the table
    cursor.executemany(query, [tuple(item.values()) for item in data])
    connection.commit()
    print(f"Data has been exported to table {table_name}")
















def import_from_csv(filepath):
    """
    Reads and returns data from a CSV file.

    Args:
        filepath (str): The path to the CSV file.

    Returns:
        list of dict: List of dictionaries representing rows.
    """
    with open(filepath, mode='r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        return [row for row in reader]




def import_from_json(filepath):
    """
    Loads data from a JSON file.

    Args:
        filepath (str): The path to the JSON file.

    Returns:
        any: The data loaded from the JSON file.
    """
    with open(filepath, 'r', encoding='utf-8') as file:
        return json.load(file)
    






def import_from_excel(filepath, sheet_name='Sheet1'):
    """
    Reads data from an Excel file.

    Args:
        filepath (str): The path to the Excel file.
        sheet_name (str): The name of the sheet to read (default is 'Sheet1').

    Returns:
        DataFrame: A pandas DataFrame containing the data.
    """
    return pd.read_excel(filepath, sheet_name=sheet_name)






def import_from_database(connection, query):
    """
    Loads data using a database query.

    Args:
        connection (sqlite3.Connection or any DB connection object): Database connection.
        query (str): SQL query to fetch data.

    Returns:
        list of tuple: List of rows fetched from the database.
    """
    cursor = connection.cursor()
    cursor.execute(query)
    return cursor.fetchall()







def get_summary(data):
    """
    Provides a quick summary of the dataset (size, data types, basic stats).

    Args:
        data (list, dict, DataFrame, or array): The data to summarize.

    Returns:
        dict: A dictionary containing the summary information.
    """
    if isinstance(data, pd.DataFrame):
        summary = {
            'shape': data.shape,
            'data_types': data.dtypes.to_dict(),
            'head': data.head().to_dict(),
            'description': data.describe().to_dict()
        }
    elif isinstance(data, list):
        summary = {
            'length': len(data),
            'types': [type(item) for item in data]
        }
    elif isinstance(data, dict):
        summary = {
            'keys': list(data.keys()),
            'types': {key: type(value) for key, value in data.items()}
        }
    else:
        summary = {'error': 'Unsupported data type for summary'}
    
    return summary






def get_schema(data):
    """
    Extracts and returns the schema of the data.

    Args:
        data (list, dict, DataFrame, or array): The data to extract schema from.

    Returns:
        dict: A dictionary containing the schema information.
    """
    if isinstance(data, pd.DataFrame):
        schema = {column: dtype for column, dtype in data.dtypes.items()}
    elif isinstance(data, list):
        schema = {
            'length': len(data),
            'types': [type(item) for item in data]
        }
    elif isinstance(data, dict):
        schema = {key: type(value) for key, value in data.items()}
    else:
        schema = {'error': 'Unsupported data type for schema'}
    
    return schema










def convert_data_format(data, target_format):
    """
    Converts data between lists, dictionaries, DataFrames, and arrays.

    Args:
        data (list, dict, DataFrame, or array): The data to convert.
        target_format (str): The target format. Options: 'list', 'dict', 'DataFrame', 'array'.

    Returns:
        Converted data in the specified format.
    """
    if target_format == 'list':
        if isinstance(data, pd.DataFrame):
            return data.values.tolist()
        elif isinstance(data, dict):
            return list(data.values())
        elif isinstance(data, np.ndarray):
            return data.tolist()
        else:
            return list(data)
    
    elif target_format == 'dict':
        if isinstance(data, pd.DataFrame):
            return data.to_dict()
        elif isinstance(data, list):
            return {i: item for i, item in enumerate(data)}
        elif isinstance(data, np.ndarray):
            return {i: item for i, item in enumerate(data.tolist())}
        else:
            return data
    
    elif target_format == 'DataFrame':
        if isinstance(data, dict):
            return pd.DataFrame.from_dict(data)
        elif isinstance(data, list):
            return pd.DataFrame(data)
        elif isinstance(data, np.ndarray):
            return pd.DataFrame(data)
        else:
            return pd.DataFrame(data)
    
    elif target_format == 'array':
        if isinstance(data, pd.DataFrame):
            return data.to_numpy()
        elif isinstance(data, list):
            return np.array(data)
        elif isinstance(data, dict):
            return np.array(list(data.values()))
        else:
            return np.array(data)
    
    else:
        raise ValueError(f"Unsupported target format: {target_format}")
    




































#pro features











def plot_data(data, plot_type='line', x_col=None, y_col=None, **kwargs):
    """
    Generates a quick plot based on the provided data and plot type.
    
    Arguments:
    - data: Data to be plotted (pandas DataFrame)
    - plot_type: Type of plot ('line', 'bar', 'scatter', etc.)
    - x_col: Column name for the x-axis
    - y_col: Column name for the y-axis
    - kwargs: Additional parameters for customizing the plot
    
    Returns:
    - A plot
    """
    plt.figure(figsize=(8, 6))

    if plot_type == 'line':
        if x_col and y_col:
            plt.plot(data[x_col], data[y_col], **kwargs)
        else:
            plt.plot(data, **kwargs)
    elif plot_type == 'bar':
        if x_col and y_col:
            plt.bar(data[x_col], data[y_col], **kwargs)
        else:
            plt.bar(data.index, data.values, **kwargs)
    elif plot_type == 'scatter':
        if x_col and y_col:
            plt.scatter(data[x_col], data[y_col], **kwargs)
        else:
            plt.scatter(data.index, data.values, **kwargs)
    else:
        raise ValueError(f"Unsupported plot type: {plot_type}")

    plt.xlabel(x_col if x_col else 'X')
    plt.ylabel(y_col if y_col else 'Y')
    plt.title(f'{plot_type.capitalize()} Plot')
    plt.grid(True)
    plt.show()




def plot_histogram(data, column, bins=10, **kwargs):
    """
    Generates a histogram for a specific column in the dataset.
    
    Arguments:
    - data: Data (pandas DataFrame)
    - column: Column name for histogram
    - bins: Number of bins
    - kwargs: Additional customization
    
    Returns:
    - Histogram plot
    """
    plt.figure(figsize=(8, 6))
    plt.hist(data[column], bins=bins, **kwargs)
    plt.xlabel(column)
    plt.ylabel('Frequency')
    plt.title(f'{column} Histogram')
    plt.grid(True)
    plt.show()





def plot_heatmap(data, **kwargs):
    """
    Creates a heatmap for correlations or other types of matrix data.
    
    Arguments:
    - data: A correlation matrix or 2D array (pandas DataFrame)
    - kwargs: Additional customization options
    
    Returns:
    - Heatmap plot
    """
    # Check if 'cmap' is in kwargs, then pop it
    cmap = kwargs.pop('cmap', 'coolwarm')  # Default to 'coolwarm' if not provided

    plt.figure(figsize=(8, 6))
    sns.heatmap(data, annot=True, cmap=cmap, **kwargs)
    plt.title('Heatmap')
    plt.show()






def plot_scatter(data, x_col, y_col, **kwargs):
    """
    Creates a scatter plot for visualizing relationships between two variables.
    
    Arguments:
    - data: Data (pandas DataFrame)
    - x_col: Column for x-axis
    - y_col: Column for y-axis
    - kwargs: Additional customization
    
    Returns:
    - Scatter plot
    """
    plt.figure(figsize=(8, 6))
    plt.scatter(data[x_col], data[y_col], **kwargs)
    plt.xlabel(x_col)
    plt.ylabel(y_col)
    plt.title(f'Scatter Plot: {x_col} vs {y_col}')
    plt.grid(True)
    plt.show()










"""
# Example Data
data = pd.DataFrame({
    'A': [1, 2, 3, 4, 5],
    'B': [2, 3, 4, 5, 6],
    'C': [5, 4, 3, 2, 1]
})

# Plot data using the functions

# Line plot
plot_data(data, plot_type='line', x_col='A', y_col='B', color='blue')

# Histogram
plot_histogram(data, column='A', bins=5, color='green')

# Heatmap
plot_heatmap(data[['A', 'B', 'C']].corr(), cmap='coolwarm')

# Scatter plot
plot_scatter(data, x_col='A', y_col='C', color='red')
"""









def pivot_data(data, index, columns, values, aggfunc='mean'):
    """
    Pivot data similar to pandas' pivot_table function.
    
    Arguments:
    data : pandas DataFrame
        The data to be pivoted.
    index : str or list
        Columns to group by.
    columns : str
        Column to pivot.
    values : str
        Column to aggregate.
    aggfunc : str, optional
        Aggregation function (default is 'mean').
    
    Returns:
    pandas DataFrame
        Pivoted DataFrame.
    """
    return data.pivot_table(index=index, columns=columns, values=values, aggfunc=aggfunc)









def scale_features(data, method='standardize'):
    """
    Scales features using methods like standardization or normalization.
    
    Arguments:
    data : pandas DataFrame
        The data to be scaled.
    method : str, optional
        Scaling method ('standardize' or 'normalize', default is 'standardize').
    
    Returns:
    pandas DataFrame
        Scaled data.
    """
    if method == 'standardize':
        scaler = StandardScaler()
        return pd.DataFrame(scaler.fit_transform(data), columns=data.columns)
    elif method == 'normalize':
        scaler = MinMaxScaler()
        return pd.DataFrame(scaler.fit_transform(data), columns=data.columns)
    else:
        raise ValueError("Method should be 'standardize' or 'normalize'")












def manipulate_datetime(data, date_column, **kwargs):
    """
    Manipulates datetime columns (parsing, extracting date parts, etc.).
    
    Arguments:
    data : pandas DataFrame
        The data containing the datetime column.
    date_column : str
        The column name containing datetime values.
    kwargs : additional keyword arguments
        The datetime manipulations (e.g., extracting year, month, day).
    
    Returns:
    pandas DataFrame
        DataFrame with updated datetime column.
    """
    data[date_column] = pd.to_datetime(data[date_column])
    
    for key, value in kwargs.items():
        if value:
            if key == 'year':
                data['Year'] = data[date_column].dt.year
            elif key == 'month':
                data['Month'] = data[date_column].dt.month
            elif key == 'day':
                data['Day'] = data[date_column].dt.day
            elif key == 'weekday':
                data['Weekday'] = data[date_column].dt.weekday
    
    return data











"""
# Example DataFrame
data = pd.DataFrame({
    'Category': ['A', 'B', 'A', 'B', 'A'],
    'Item': ['X', 'X', 'Y', 'Y', 'X'],
    'Sales': [100, 150, 200, 250, 300],
    'Date': ['2023-01-01', '2023-02-01', '2023-03-01', '2023-04-01', '2023-05-01']
})

# Example 1: Pivot Data
pivoted_data = pivot_data(data, index='Category', columns='Item', values='Sales', aggfunc='sum')
print("Pivoted Data:")
print(pivoted_data)

# Example 2: Scale Features (Standardize)
scaled_data = scale_features(data[['Sales']], method='standardize')
print("\nScaled Data (Standardized):")
print(scaled_data)

# Example 3: Manipulate Datetime (Extract Year, Month, Day)
modified_data = manipulate_datetime(data, date_column='Date', year=True, month=True, day=True)
print("\nModified Data with Year, Month, and Day:")
print(modified_data)
"""








def simple_imputation(data, method='mean'):
    """
    Imputes missing values using mean, median, or mode.
    
    Arguments:
        data: Data (pandas DataFrame)
        method: Imputation method ('mean', 'median', 'mode')
    
    Returns:
        Data with imputed values.
    """
    if method == 'mean':
        data = data.fillna(data.mean())
    elif method == 'median':
        data = data.fillna(data.median())
    elif method == 'mode':
        data = data.fillna(data.mode().iloc[0])
    else:
        raise ValueError("Invalid method. Choose from 'mean', 'median', or 'mode'.")
    return data

def advanced_imputation(data, method='knn'):
    """
    Uses advanced methods like KNN or regression for imputing missing values.
    
    Arguments:
        data: Data (pandas DataFrame)
        method: Imputation method ('knn', 'regression')
    
    Returns:
        Data with imputed values.
    """
    if method == 'knn':
        imputer = KNNImputer(n_neighbors=5)
        data_imputed = imputer.fit_transform(data)
        return pd.DataFrame(data_imputed, columns=data.columns)
    elif method == 'regression':
        # Simple Linear Regression for imputation of missing values
        data_imputed = data.copy()
        for column in data.columns:
            if data[column].isnull().sum() > 0:
                model = LinearRegression()
                not_null_data = data[column].dropna()
                X_train = data.dropna()[data[column].isnull() == False].drop(columns=[column])
                y_train = not_null_data
                model.fit(X_train, y_train)
                missing_values = data[column].isnull()
                X_missing = data[missing_values].drop(columns=[column])
                data_imputed[column] = data_imputed[column].fillna(model.predict(X_missing))
        return data_imputed
    else:
        raise ValueError("Invalid method. Choose from 'knn' or 'regression'.")

def visualize_missing(data):
    """
    Visualizes missing data (e.g., heatmap or matrix).
    
    Arguments:
        data: Data (pandas DataFrame)
    
    Returns:
        Visualization of missing values.
    """
    plt.figure(figsize=(10, 6))
    sns.heatmap(data.isnull(), cbar=False, cmap='viridis')
    plt.title('Missing Data Heatmap')
    plt.show()




"""

    # Sample DataFrame with missing values
data = pd.DataFrame({
    'A': [1, 2, None, 4, 5],
    'B': [None, 2, 3, None, 5],
    'C': [1, None, None, 4, 5]
})

# Simple Imputation
data_imputed_simple = simple_imputation(data, method='mean')
print(data_imputed_simple)

# Advanced Imputation (KNN)
data_imputed_advanced = advanced_imputation(data, method='knn')
print(data_imputed_advanced)

# Visualize missing data
visualize_missing(data)
"""















def process_in_parallel(data, function, n_jobs=4):
    """
    Applies a function to data in parallel using multiple threads or processes.

    Arguments:
    - data: pandas DataFrame
    - function: Function to apply to the data
    - n_jobs: Number of parallel jobs (default is 4)

    Returns:
    - Processed data.
    """
    return Parallel(n_jobs=n_jobs)(delayed(function)(chunk) for chunk in data)







async def asynchronous_processing(function, *args, **kwargs):
    """
    Runs a function asynchronously to handle large datasets without blocking the main thread.

    Arguments:
    - function: Function to execute
    - args: Arguments for the function
    - kwargs: Keyword arguments for the function

    Returns:
    - Asynchronous result.
    """
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, function, *args, **kwargs)
    return result

"""

# Sample DataFrame
data = pd.DataFrame({
    'A': np.random.rand(1000),
    'B': np.random.rand(1000),
    'C': np.random.rand(1000)
})

# Function to process a chunk of data
def process_chunk(chunk):
    # Example processing: Sum the values of each row
    return chunk.sum(axis=1)

# Split data into chunks (for simplicity, let's split by row index here)
chunks = np.array_split(data, 4)  # Split into 4 chunks

# Apply the function in parallel
processed_data = process_in_parallel(chunks, process_chunk, n_jobs=4)

# Combine results back into a DataFrame
result = pd.concat(processed_data, ignore_index=True)

print(result)
"""









"""

# Function to simulate a long-running task
def long_running_task(seconds):
    print(f"Task starting for {seconds} seconds")
    time.sleep(seconds)
    return f"Task completed after {seconds} seconds"

# Asynchronous wrapper to handle long-running task
async def main():
    result1 = await asynchronous_processing(long_running_task, 2)
    result2 = await asynchronous_processing(long_running_task, 3)
    
    print(result1)
    print(result2)

# Run the asynchronous main function
asyncio.run(main())

"""






# Function to extract features for machine learning
def extract_features(data, target_col, method='statistical'):
    """
    Extracts features for machine learning models using specified methods.
    
    Arguments:
    - data: pandas DataFrame containing the data
    - target_col: Target column name to predict
    - method: Feature extraction method (default is 'statistical')
    
    Returns:
    - Extracted features as a pandas DataFrame
    """
    
    # Check if target column exists
    if target_col not in data.columns:
        raise ValueError(f"Target column '{target_col}' not found in the data.")
    
    X = data.drop(columns=[target_col])  # Features
    y = data[target_col]  # Target

    if method == 'statistical':
        # Example of extracting statistical features: mean, std, skewness, kurtosis
        statistical_features = pd.DataFrame({
            'mean': X.mean(axis=0),
            'std': X.std(axis=0),
            'skew': X.skew(axis=0),
            'kurtosis': X.kurtosis(axis=0),
        }).T
        return statistical_features
    else:
        # You can add other methods here, like domain-specific or model-based extraction
        raise ValueError(f"Unknown method: {method}")

# Function to preprocess data for machine learning
def preprocess_data_for_ml(data, method='scaling'):
    """
    Prepares data for machine learning by scaling, encoding, or normalizing.
    
    Arguments:
    - data: pandas DataFrame containing the data
    - method: Preprocessing method ('scaling' or 'encoding')
    
    Returns:
    - Preprocessed data as a pandas DataFrame
    """
    
    if method == 'scaling':
        # Example: Scale the data using StandardScaler or MinMaxScaler
        scaler = StandardScaler()
        scaled_data = pd.DataFrame(scaler.fit_transform(data), columns=data.columns)
        return scaled_data
    elif method == 'encoding':
        # Example: Apply Label Encoding for categorical variables
        categorical_columns = data.select_dtypes(include=['object']).columns
        encoded_data = data.copy()
        for col in categorical_columns:
            encoded_data[col] = encoded_data[col].astype('category').cat.codes
        return encoded_data
    else:
        raise ValueError(f"Unknown method: {method}")

"""
# Example usage
if __name__ == "__main__":
    # Sample data for demonstration
    data = pd.DataFrame({
        'age': [25, 30, 35, 40],
        'salary': [50000, 60000, 70000, 80000],
        'target': [0, 1, 0, 1]
    })
    
    # Extracting features
    features = extract_features(data, target_col='target', method='statistical')
    print("Extracted Features:\n", features)
    
    # Preprocessing data for machine learning (scaling)
    preprocessed_data = preprocess_data_for_ml(data.drop(columns='target'), method='scaling')
    print("Preprocessed Data (Scaled):\n", preprocessed_data)
"""






# Function to generate a data profile
def profile_data(data):
    """
    Generates a data profile to check for anomalies, distributions, and outliers.

    Arguments:
    - data: pandas DataFrame containing the data to be profiled.

    Returns:
    - A dictionary containing summary statistics, anomalies, and missing values.
    """
    # Filtering out non-numeric columns for quantile-based anomaly detection
    numeric_data = data.select_dtypes(include=[np.number])

    profile = {
        'summary_statistics': data.describe(),
        'anomalies': numeric_data.apply(
            lambda x: x[(x < x.quantile(0.01)) | (x > x.quantile(0.99))]
        ),
        'missing_values': data.isnull().sum(),
    }
    return profile






# Function to monitor data quality
def monitor_data_quality(data):
    """
    Monitors data quality by checking completeness, consistency, and validity.

    Arguments:
    - data: pandas DataFrame containing the data to be monitored.

    Returns:
    - A dictionary containing the percentage of missing values and valid entries.
    """
    quality_scores = {
        'missing_values_percentage': data.isnull().mean() * 100,
        'valid_entries_percentage': (data.notnull().mean()) * 100
    }
    return quality_scores






# Function to alert on data quality issues
def alert_on_data_quality_issues(data):
    """
    Alerts users about detected data quality issues, such as missing values or incorrect data types.

    Arguments:
    - data: pandas DataFrame containing the data to check for quality issues.

    Returns:
    - A message indicating the detected issues, or a confirmation that data quality is good.
    """
    missing_values = data.isnull().sum().sum()
    if missing_values > 0:
        return f"Alert: {missing_values} missing values detected."
    
    incorrect_types = data.dtypes[data.dtypes == 'object'].index
    if len(incorrect_types) > 0:
        return f"Alert: Incorrect data types detected in columns: {', '.join(incorrect_types)}"
    
    return "Data quality is good."


"""
# Example usage:

# Sample data
data = pd.DataFrame({
    'age': [25, 30, np.nan, 40],
    'salary': [50000, np.nan, 70000, 80000],
    'gender': ['Male', 'Female', 'Female', 'Male'],
})

# 1. Profile the data
profile = profile_data(data)
print("Data Profile:\n", profile)

# 2. Monitor data quality
quality_scores = monitor_data_quality(data)
print("Data Quality Scores:\n", quality_scores)

# 3. Alert on data quality issues
alert = alert_on_data_quality_issues(data)
print("Data Quality Alert:\n", alert)
# Sample data for testing
data = pd.DataFrame({
    'age': [25, 30, np.nan, 40],
    'salary': [50000, np.nan, 70000, 80000],
    'gender': ['Male', 'Female', 'Female', 'Male'],
})

# Generate data profile
profile = profile_data(data)
print("Data Profile:\n", profile)
"""


import pandas as pd
import copy
from typing import List

# Initialize a global variable to track changes and data versions
changes_log = []
data_versions = []

def track_changes(data: pd.DataFrame) -> pd.DataFrame:
    """
    Tracks changes to datasets and logs each transformation.

    Arguments:
        data (pd.DataFrame): The dataset (pandas DataFrame).

    Returns:
        pd.DataFrame: Updated dataset with logged changes.
    """
    # Create a deep copy of the dataset to ensure no modification of the original
    updated_data = copy.deepcopy(data)
    
    # Record the change (timestamp and preview of the data)
    change_entry = {
        'change_description': f"Updated dataset at {pd.Timestamp.now()}",
        'new_data': updated_data.head()  # Log a preview of the first few rows
    }

    # Append this change to the changes log
    changes_log.append(change_entry)

    # Save the current version of the data (to enable rollback)
    data_versions.append(updated_data)

    return updated_data

def rollback_data_version(version_id: int) -> pd.DataFrame:
    """
    Rolls back the dataset to a previous version.

    Arguments:
        version_id (int): The ID of the version to roll back to.

    Returns:
        pd.DataFrame: The dataset rolled back to the requested version.
    """
    if version_id < len(data_versions) and version_id >= 0:
        return data_versions[version_id]
    else:
        raise ValueError(f"Invalid version_id: {version_id}. Available versions: 0-{len(data_versions)-1}")


"""
# Example Usage:

# Sample data
data = pd.DataFrame({
    'age': [25, 30, 35],
    'salary': [50000, 60000, 70000]
})

# Track the change in the dataset
updated_data = track_changes(data)

# Track another change
data['salary'] = [55000, 65000, 75000]  # Modify the data
updated_data = track_changes(data)

# Rollback to version 0 (initial version)
rolled_back_data = rollback_data_version(version_id=0)

# Display results
print("Updated Data:")
print(updated_data)

print("\nChanges Log:")
print(changes_log)

print("\nRolled Back Data:")
print(rolled_back_data)

"""





import pandas as pd

def export_data(data, format='csv', compression=None):
    """
    Exports a single DataFrame to a specified file format.
    
    Arguments:
    - data (pandas DataFrame): The DataFrame to export.
    - format (str): The file format to export to ('csv', 'parquet', 'hdf5').
    - compression (str or None): The compression type ('gzip', 'zip', etc.).
    
    Returns:
    - str: The name of the exported file.
    """
    # Define the export file name based on format
    file_name = f"exported_data.{format}"
    
    # Export based on format
    if format == 'csv':
        data.to_csv(file_name, compression=compression)
    elif format == 'parquet':
        data.to_parquet(file_name, compression=compression)
    elif format == 'hdf5':
        data.to_hdf(file_name, compression=compression)
    else:
        raise ValueError("Unsupported format")
    
    return file_name  # Return the name of the exported file

def batch_export(data, formats=['csv'], compression=None):
    """
    Exports one or more DataFrames to the specified formats.
    
    Arguments:
    - data (pandas DataFrame or list of pandas DataFrames): Data or list of DataFrames to export.
    - formats (list of str): List of formats to export the DataFrames to ('csv', 'parquet', 'hdf5').
    - compression (str or None): Compression type ('gzip', 'zip', etc.).
    
    Returns:
    - list of str: List of file names for the exported files.
    """
    # If data is not a list, make it a list for consistent processing
    if not isinstance(data, list):
        data = [data]
    
    exported_files = []  # List to store exported file names

    # Iterate over the list of DataFrames
    for index, df in enumerate(data):
        # For each DataFrame, export it to each format
        for fmt in formats:
            file_name = f"exported_data_{index + 1}.{fmt}"  # Ensure unique file names
            # Export the DataFrame and store the file name
            exported_file = export_data(df, format=fmt, compression=compression)
            exported_files.append(exported_file)  # Add the exported file to the list
    
    return exported_files  # Return the list of exported files




"""
# Example usage with a single DataFrame or list of DataFrames
data1 = pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})
data2 = pd.DataFrame({'X': [7, 8, 9], 'Y': [10, 11, 12]})

# Batch export with a single DataFrame
exported_files_single = batch_export(data1, formats=['csv', 'parquet'], compression='gzip')
print("Exported files from single DataFrame:", exported_files_single)

# Batch export with a list of DataFrames
exported_files_list = batch_export([data1, data2], formats=['csv', 'parquet'], compression='gzip')
print("Exported files from list of DataFrames:", exported_files_list)

"""







# Function for sampling data based on different methods
def sample_data(data, method='random', size=None):
    """
    Samples data using random, stratified, or systematic methods.
    
    Arguments:
    - data: pandas DataFrame
    - method: str ('random', 'stratified', 'systematic')
    - size: int, sample size
    
    Returns:
    - pandas DataFrame of sampled data
    """
    if method == 'random':
        # Random Sampling
        return data.sample(n=size)
    
    elif method == 'stratified':
        # Stratified Sampling (using train_test_split to keep the distribution)
        if 'target' in data.columns:
            X = data.drop(columns='target')
            y = data['target']
            _, sampled_data, _, _ = train_test_split(X, y, test_size=size/len(data), stratify=y)
            return pd.concat([sampled_data, y.loc[sampled_data.index]], axis=1)
        else:
            raise ValueError("Stratified sampling requires a 'target' column for stratification.")
    
    elif method == 'systematic':
        # Systematic Sampling (sample every nth item)
        if size is None:
            size = len(data) // 10  # default to sampling 10% if size is not specified
        step = len(data) // size
        return data.iloc[::step]
    
    else:
        raise ValueError("Invalid method. Choose from 'random', 'stratified', or 'systematic'.")

# Function for reservoir sampling on a data stream
def reservoir_sampling(stream_data, size):
    """
    Applies reservoir sampling for streaming data.
    
    Arguments:
    - stream_data: iterable, data stream
    - size: int, sample size
    
    Returns:
    - List containing the sampled data
    """
    reservoir = []
    
    for i, data_point in enumerate(stream_data):
        if i < size:
            reservoir.append(data_point)  # Fill the reservoir initially
        else:
            # For subsequent elements, replace an element in the reservoir randomly
            j = np.random.randint(0, i + 1)
            if j < size:
                reservoir[j] = data_point
    
    return reservoir


"""
# Example usage:

# Sample pandas DataFrame
data = pd.DataFrame({
    'A': np.random.rand(1000),
    'B': np.random.rand(1000),
    'target': np.random.choice([0, 1], size=1000)
})

# Random sampling
random_sample = sample_data(data, method='random', size=100)

# Stratified sampling
stratified_sample = sample_data(data, method='stratified', size=100)

# Systematic sampling
systematic_sample = sample_data(data, method='systematic', size=100)

# Example of streaming data for reservoir sampling
stream_data = (i for i in range(1000))  # Simulated streaming data
reservoir_sample = reservoir_sampling(stream_data, size=100)

# Print results
print("Random Sample:")
print(random_sample.head())

print("\nStratified Sample:")
print(stratified_sample.head())

print("\nSystematic Sample:")
print(systematic_sample.head())

print("\nReservoir Sample:")
print(reservoir_sample[:10])  # Print first 10 elements of the reservoir sample
"""





