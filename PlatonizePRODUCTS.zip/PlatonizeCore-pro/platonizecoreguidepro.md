# PlationData Library Documentation

## 1. Data Manipulation Utilities

### Lists
* `filter_list(data, condition)`
* `sort_list(data, key=None, reverse=False)`
* `transform_list(data, function)`
* `merge_lists(list1, list2, merge_func)`
* `aggregate_list(data, agg_func)`

### Dictionaries
* `filter_dict(data, condition)`
* `map_dict(data, transform_func)`
* `merge_dicts(dict1, dict2, conflict_resolver)`
* `group_by_key(data, key)`

### Pandas DataFrames
* `filter_df(df, condition)`
* `sort_df(df, columns, ascending=True)`
* `transform_df(df, column, function)`
* `merge_dfs(df1, df2, on, how='inner')`
* `aggregate_df(df, group_by, agg_func)`

### NumPy Arrays
* `filter_array(array, condition)`
* `sort_array(array, axis=-1)`
* `transform_array(array, function)`
* `aggregate_array(array, agg_func, axis=None)`

## 2. Simplified Data Operations
* `filter_data(data, condition)`
* `sort_data(data, key=None, reverse=False)`
* `transform_data(data, function)`
* `merge_data(data1, data2, merge_func=None)`
* `aggregate_data(data, agg_func)`

## 3. Validation and Error Handling
* `validate_data(data, schema)`
* `validate_file(filepath, format)`
* `handle_errors(operation, fallback)`

## 4. Customizable Data Pipelines
* `create_pipeline(steps)`
* `run_pipeline(data, pipeline)`
* `process_batch(batch, pipeline)`
* `stream_data(data_source, pipeline)`

## 5. Data Export and Import

### Exporting
* `export_to_csv(data, filepath)`
* `export_to_json(data, filepath)`
* `export_to_excel(data, filepath, sheet_name='Sheet1')`
* `export_to_database(data, connection, table_name)`

### Importing
* `import_from_csv(filepath)`
* `import_from_json(filepath)`
* `import_from_excel(filepath, sheet_name='Sheet1')`
* `import_from_database(connection, query)`

## 6. Utility Functions
* `get_summary(data)`
* `get_schema(data)`
* `convert_data_format(data, target_format)`





# PlatonizeCore Plotting 

 ## Functions Documentation

## 1. Data Plotting Functions

### General Plotting
* `plot_data(data, plot_type='line', x_col=None, y_col=None, **kwargs)`
    - Generates a quick plot based on the provided data and plot type (e.g., line, bar, scatter, etc.)
  
### Histograms
* `plot_histogram(data, column, bins=10, **kwargs)`
    - Generates a histogram for a specific column in the dataset.
  
### Heatmaps
* `plot_heatmap(data, **kwargs)`
    - Creates a heatmap for correlations or other types of matrix data.
  
### Scatter Plots
* `plot_scatter(data, x_col, y_col, **kwargs)`
    - Creates a scatter plot for visualizing relationships between two variables.

## 2. Customization Options

- **title**: Sets the title of the plot (e.g., `title='My Plot'`).
- **xlabel**: Label for the x-axis (e.g., `xlabel='X Axis'`).
- **ylabel**: Label for the y-axis (e.g., `ylabel='Y Axis'`).
- **color**: Color of the plot elements (e.g., `color='blue'` for lines or bars).
- **linewidth**: Width of the line in a line plot (e.g., `linewidth=2`).
- **fontsize**: Font size for labels and title (e.g., `fontsize=12`).

## 3. Example Usages

### Example 1: Line Plot
```python
import pandas as pd
from PlatonizeCorepro import plot_data

data = pd.DataFrame({
    'x': [1, 2, 3, 4, 5],
    'y': [5, 4, 3, 2, 1]
})

plot_data(data, plot_type='line', x_col='x', y_col='y', title='Line Plot', xlabel='X Values', ylabel='Y Values')

```

## 1. Data Manipulation Utilities

### Pivoting Data
* `pivot_data(data, index, columns, values, aggfunc='mean')`
    - Pivot data similar to pandas' `pivot_table` function.
    - **Arguments**:
        - `data`: pandas DataFrame
        - `index`: Columns to group by
        - `columns`: Column to pivot
        - `values`: Column to aggregate
        - `aggfunc`: Aggregation function (default is 'mean')
    - **Returns**: Pivoted DataFrame

### Scaling Features
* `scale_features(data, method='standardize')`
    - Scales features using methods like standardization or normalization.
    - **Arguments**:
        - `data`: pandas DataFrame
        - `method`: Scaling method ('standardize' or 'normalize', default is 'standardize')
    - **Returns**: Scaled data (pandas DataFrame)

### Manipulating Datetime Columns
* `manipulate_datetime(data, date_column, **kwargs)`
    - Manipulates datetime columns (parsing, - **Arguments**:
        - `data`: pandas DataFrame
        - `date_column`: Column name containing datetime values
        - `kwargs`: Additional date manipulations (e.g., extracting year, month, day, etc.)
    - **Returns**: Updated DataFrame with datetime manipulationsextracting date parts, etc.).
    




### 1. Simple Imputation
* `simple_imputation(data, method='mean')`
    - Imputes missing values using mean, median, or mode.
    - **Arguments**:
        - `data`: pandas DataFrame
        - `method`: Imputation method ('mean', 'median', 'mode')
    - **Returns**: Data with imputed values.

---

### 2. Advanced Imputation
* `advanced_imputation(data, method='knn')`
    - Uses advanced methods like KNN or regression for imputing missing values.
    - **Arguments**:
        - `data`: pandas DataFrame
        - `method`: Imputation method ('knn', 'regression')
    - **Returns**: Data with imputed values.

---

### 3. Visualizing Missing Data
* `visualize_missing(data)`
    - Visualizes missing data (e.g., heatmap or matrix).
    - **Arguments**:
        - `data`: pandas DataFrame
    - **Returns**: Visualization of missing values.






### 1. Parallel and Asynchronous Processing

* `process_in_parallel(data, function, n_jobs=4)`
    - Applies a function to data in parallel using multiple threads or processes.
    - **Arguments**:
        - `data`: pandas DataFrame or list of DataFrames
        - `function`: Function to apply to each chunk of data
        - `n_jobs`: Number of parallel jobs to run (default is 4)
    - **Returns**: A list of DataFrames with the processed data.

* `asynchronous_processing(function, *args, **kwargs)`
    - Runs a function asynchronously to handle large datasets without blocking the main thread.
    - **Arguments**:
        - `function`: Function to execute asynchronously
        - `args`: Arguments for the function
        - `kwargs`: Keyword arguments for the function
    - **Returns**: The result of the function execution.




# Guide to Feature Extraction and Preprocessing for Machine Learning

### 1. Feature Extraction
* `extract_features(data, target_col, method='statistical')`
    - Extracts features for machine learning models using specified methods (e.g., statistical methods).
    - **Arguments**:
        - `data`: pandas DataFrame containing the data.
        - `target_col`: The name of the target column to predict (e.g., 'target').
        - `method`: Feature extraction method ('statistical' by default).
    - **Returns**: A DataFrame containing the extracted features based on the selected method.

---

### 2. Data Preprocessing for Machine Learning
* `preprocess_data_for_ml(data, method='scaling')`
    - Prepares data for machine learning by scaling, encoding, or normalizing the features.
    - **Arguments**:
        - `data`: pandas DataFrame containing the features to preprocess.
        - `method`: Preprocessing method ('scaling' for standardization or 'encoding' for label encoding).
    - **Returns**: A DataFrame containing the preprocessed data (either scaled or encoded).

---

## Example Code:

```python
import pandas as pd
from sklearn.preprocessing import StandardScaler

# Feature extraction function
def extract_features(data, target_col, method='statistical'):
    if target_col not in data.columns:
        raise ValueError(f"Target column '{target_col}' not found in the data.")
    
    X = data.drop(columns=[target_col])
    y = data[target_col]

    if method == 'statistical':
        statistical_features = pd.DataFrame({
            'mean': X.mean(axis=0),
            'std': X.std(axis=0),
            'skew': X.skew(axis=0),
            'kurtosis': X.kurtosis(axis=0),
        }).T
        return statistical_features
    else:
        raise ValueError(f"Unknown method: {method}")

# Preprocessing function
def preprocess_data_for_ml(data, method='scaling'):
    if method == 'scaling':
        scaler = StandardScaler()
        scaled_data = pd.DataFrame(scaler.fit_transform(data), columns=data.columns)
        return scaled_data
    elif method == 'encoding':
        categorical_columns = data.select_dtypes(include=['object']).columns
        encoded_data = data.copy()
        for col in categorical_columns:
            encoded_data[col] = encoded_data[col].astype('category').cat.codes
        return encoded_data
    else:
        raise ValueError(f"Unknown method: {method}")

# Sample data
data = pd.DataFrame({
    'age': [25, 30, 35, 40],
    'salary': [50000, 60000, 70000, 80000],
    'target': [0, 1, 0, 1]
})

# Feature extraction
features = extract_features(data, target_col='target', method='statistical')
print("Extracted Features:\n", features)

# Data preprocessing (scaling)
preprocessed_data = preprocess_data_for_ml(data.drop(columns='target'), method='scaling')
print("Preprocessed Data (Scaled):\n", preprocessed_data)
```







### 1. Data Profiling and Monitoring
* `profile_data(data)`
    - Generates a data profile to check for anomalies, distributions, and outliers.
    - **Arguments**:
        - `data`: pandas DataFrame containing the data to profile.
    - **Returns**: A dictionary containing summary statistics, detected anomalies, and missing values.

* `monitor_data_quality(data)`
    - Monitors data quality by checking completeness, consistency, and validity.
    - **Arguments**:
        - `data`: pandas DataFrame to monitor.
    - **Returns**: A pandas Series with quality scores such as percentage of missing values and valid entries.

* `alert_on_data_quality_issues(data)`
    - Alerts users about detected data quality issues (e.g., missing values, incorrect data types).
    - **Arguments**:
        - `data`: pandas DataFrame to check for issues.
    - **Returns**: A notification or alert message detailing detected issues.

---

### 1. Tracking Dataset Changes
* `track_changes(data)`
    - Tracks changes to datasets and logs each transformation.
    - **Arguments**:
        - `data`: pandas DataFrame containing the dataset to track changes for.
    - **Returns**: Updated dataset with the logged change.

---

### 2. Rolling Back Dataset to a Previous Version
* `rollback_data_version(version_id)`
    - Rolls back the dataset to a previous version.
    - **Arguments**:
        - `version_id`: The ID of the version to roll back to (an integer representing the version).
    - **Returns**: The dataset rolled back to the requested version.

---

### Example Usage

```python
import pandas as pd

# Sample data
data = pd.DataFrame({
    'age': [25, 30, 35],
    'salary': [50000, 60000, 70000]
})

# Track the change in the dataset
updated_data = track_changes(data)

# Track another change
data['salary'] = [55000, 65000, 75000]  # Modify the data
updated_data = track_changes(data)

# Rollback to version 0 (initial version)
rolled_back_data = rollback_data_version(version_id=0)

# Display results
print("Updated Data:")
print(updated_data)

print("\nChanges Log:")
print(changes_log)

print("\nRolled Back Data:")
print(rolled_back_data)
```



### 1. Data Export for Different Formats

* `export_data(data, format='csv', compression=None)`
    - Exports a single DataFrame to a specified file format.
    - **Arguments**:
        - `data`: A pandas DataFrame containing the data to export.
        - `format`: The file format to export to. Supported formats are 'csv', 'parquet', and 'hdf5'.
        - `compression`: The compression type ('gzip', 'zip', etc.) or `None`.
    - **Returns**: The name of the exported file (e.g., `exported_data.csv`).

---

### 2. Batch Export Multiple DataFrames

* `batch_export(data, formats=['csv'], compression=None)`
    - Exports one or more DataFrames to the specified formats.
    - **Arguments**:
        - `data`: A pandas DataFrame or a list of DataFrames to export.
        - `formats`: A list of formats to export to. Supported formats are 'csv', 'parquet', and 'hdf5'.
        - `compression`: The compression type ('gzip', 'zip', etc.) or `None`.
    - **Returns**: A list of file names for the exported files (e.g., `['exported_data_1.csv', 'exported_data_1.parquet']`).

---

### Example Usage:

#### Export a Single DataFrame:
```python
import pandas as pd

# Sample DataFrame
data1 = pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})

# Export the DataFrame to CSV and Parquet formats
exported_files_single = batch_export(data1, formats=['csv', 'parquet'], compression='gzip')
print("Exported files from single DataFrame:", exported_files_single)
```


# Data Sampling and Reservoir Sampling in Python

This document explains two functions: `sample_data` and `reservoir_sampling` for data manipulation and sampling in Python.

## Functions:

### 1. **sample_data** function
The `sample_data` function samples data from a pandas DataFrame using three different methods:

- **Random Sampling**
- **Stratified Sampling**
- **Systematic Sampling**

#### Arguments:
- `data`: A pandas DataFrame containing the data to be sampled.
- `method`: Sampling method ('random', 'stratified', 'systematic').
- `size`: The number of samples to return.

#### Returns:
A pandas DataFrame containing the sampled data.

### 2. **reservoir_sampling** function
The `reservoir_sampling` function implements the **reservoir sampling** technique, which is useful when sampling data from a **streaming dataset** or an environment where you cannot store all data in memory at once.

#### Arguments:
- `stream_data`: An iterable representing the data stream.
- `size`: The number of samples to return.

#### Returns:
A list containing the sampled data.

---

## Python Code:

```python
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split

# Function for sampling data based on different methods
def sample_data(data, method='random', size=None):
    """
    Samples data using random, stratified, or systematic methods.
    
    Arguments:
    - data: pandas DataFrame
    - method: str ('random', 'stratified', 'systematic')
    - size: int, sample size
    
    Returns:
    - pandas DataFrame of sampled data
    """
    if method == 'random':
        # Random Sampling
        return data.sample(n=size)
    
    elif method == 'stratified':
        # Stratified Sampling (using train_test_split to keep the distribution)
        if 'target' in data.columns:
            X = data.drop(columns='target')
            y = data['target']
            _, sampled_data, _, _ = train_test_split(X, y, test_size=size/len(data), stratify=y)
            return pd.concat([sampled_data, y.loc[sampled_data.index]], axis=1)
        else:
            raise ValueError("Stratified sampling requires a 'target' column for stratification.")
    
    elif method == 'systematic':
        # Systematic Sampling (sample every nth item)
        if size is None:
            size = len(data) // 10  # default to sampling 10% if size is not specified
        step = len(data) // size
        return data.iloc[::step]
    
    else:
        raise ValueError("Invalid method. Choose from 'random', 'stratified', or 'systematic'.")

# Function for reservoir sampling on a data stream
def reservoir_sampling(stream_data, size):
    """
    Applies reservoir sampling for streaming data.
    
    Arguments:
    - stream_data: iterable, data stream
    - size: int, sample size
    
    Returns:
    - List containing the sampled data
    """
    reservoir = []
    
    for i, data_point in enumerate(stream_data):
        if i < size:
            reservoir.append(data_point)  # Fill the reservoir initially
        else:
            # For subsequent elements, replace an element in the reservoir randomly
            j = np.random.randint(0, i + 1)
            if j < size:
                reservoir[j] = data_point
    
    return reservoir


# Example usage:

# Sample pandas DataFrame
data = pd.DataFrame({
    'A': np.random.rand(1000),
    'B': np.random.rand(1000),
    'target': np.random.choice([0, 1], size=1000)
})

# Random sampling
random_sample = sample_data(data, method='random', size=100)

# Stratified sampling
stratified_sample = sample_data(data, method='stratified', size=100)

# Systematic sampling
systematic_sample = sample_data(data, method='systematic', size=100)

# Example of streaming data for reservoir sampling
stream_data = (i for i in range(1000))  # Simulated streaming data
reservoir_sample = reservoir_sampling(stream_data, size=100)

# Print results
print("Random Sample:")
print(random_sample.head())

print("\nStratified Sample:")
print(stratified_sample.head())

print("\nSystematic Sample:")
print(systematic_sample.head())

print("\nReservoir Sample:")
print(reservoir_sample[:10])  # Print first 10 elements of the reservoir sample
```